// @target: pinball.remote.ApiUrlBuilder
// @name: Redirect the game server to your own URL
// @desc: Points the API server at the URL you configure below, so the game
//        talks to your own server instead of the (shut down) official one.
//        The final URL is <serverUrl>/<branch>/api/index.php, e.g.
//        http://127.0.0.1:8080/latest/api/index.php
// @enabled: true
// @config: serverUrl = http://127.0.0.1:8080 | Base URL of your private server, no trailing slash
//
// Whole-class replacement of the API URL builder. Only apiBase() changes
// behaviour: for ApiServerKind.Production it now returns the configured URL
// instead of the (always empty on PC) value the Kakao ANE reports. Everything
// else is a faithful, self-contained reimplementation that avoids the classes
// this build leaves unnamed - see README ("Server redirect").
//
// The class keeps `init__` and `apiUrlBase` because the boot ABC writes both
// while running this class's static initialiser.
package pinball.remote
{
   import haxe.ds.Option;
   import pinball.config.kind.ApiServerKind;

   public class ApiUrlBuilder
   {
      public static var init__:Boolean;

      public static var apiUrlBase:String;

      public function ApiUrlBuilder()
      {
      }

      public static function apiBase(param1:ApiServerKind) : String
      {
         switch(param1.index)
         {
            case 0:
               return "{{serverUrl}}";
            case 1:
               return param1.params[0];
            case 2:
               return param1.params[0];
            case 3:
               return param1.params[0];
            default:
               throw "unsupported ApiServerKind in apiBase";
         }
      }

      public static function apiPath(param1:ApiServerKind, param2:Option) : String
      {
         switch(param2.index)
         {
            case 0:
               return "/" + param2.params[0];
            case 1:
               switch(param1.index)
               {
                  case 0:
                     return apiUrlBase;
                  case 1:
                     return apiUrlBase;
                  case 2:
                     return apiUrlBase;
                  case 3:
                     return apiUrlBase;
                  default:
                     throw "unsupported ApiServerKind in apiPath";
               }
            default:
               throw "unsupported Option in apiPath";
         }
      }

      public static function apiBaseOption(param1:ApiServerKind, param2:Option) : Option
      {
         switch(param2.index)
         {
            case 0:
               return Option.Some("" + param2.params[0]);
            case 1:
               switch(param1.index)
               {
                  case 0:
                     return Option.None;
                  case 1:
                     return Option.None;
                  case 2:
                     return Option.None;
                  case 3:
                     return Option.None;
                  default:
                     throw "unsupported ApiServerKind in apiBaseOption";
               }
            default:
               throw "unsupported Option in apiBaseOption";
         }
      }

      public static function assertNoAssetDownload(param1:ApiServerKind) : String
      {
         throw "downloading assets from the server is not allowed in this build";
      }

      public static function assetDownloadServerOption(param1:ApiServerKind) : Option
      {
         switch(param1.index)
         {
            case 0:
               return Option.None;
            case 1:
               return Option.Some(param1.params[1]);
            case 2:
               return Option.Some(param1.params[1]);
            case 3:
               return Option.Some(param1.params[1]);
            default:
               throw "unsupported ApiServerKind in assetDownloadServerOption";
         }
      }

      public static function getApiUrl(param1:ApiServerKind, param2:Option) : String
      {
         var _loc3_:String = apiBase(param1);
         var _loc4_:String = apiPath(param1,param2);
         return _loc3_ + _loc4_ + "/api/index.php";
      }

      public static function getApiUrlFromString(param1:String, param2:Option) : String
      {
         return getApiUrl(ApiServerKind.Production,param2);
      }

      public static function apiBranchName(param1:ApiServerKind, param2:Option) : String
      {
         var _loc3_:String = null;
         var _loc4_:String = null;
         switch(param1.index)
         {
            case 0:
               _loc3_ = "production";
               break;
            case 1:
               _loc3_ = "staging";
               break;
            case 2:
               _loc3_ = "pinstg";
               break;
            case 3:
               _loc3_ = "pinstgrev";
               break;
            default:
               _loc3_ = "unknown";
         }
         switch(param2.index)
         {
            case 0:
               _loc4_ = "---" + ("" + param2.params[0]).split("/").join("___");
               break;
            case 1:
               _loc4_ = "";
               break;
            default:
               _loc4_ = "";
         }
         return _loc3_ + _loc4_;
      }

      public static function isApiEnabled(param1:ApiServerKind) : Boolean
      {
         switch(param1.index)
         {
            case 0:
               return true;
            case 1:
               return true;
            case 2:
               return true;
            case 3:
               return true;
            default:
               return false;
         }
      }
   }
}
