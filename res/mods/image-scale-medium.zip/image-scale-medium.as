package obf
{
   import flash.Boot;
   import flash.display.StageScaleMode;
   import haxe.ds.Option;
   import pinball.context.screenSize.ImageScale;
   
   public class Cogmdbohkpjobbkk extends Cemhlflbfijhlbfj implements Clfcilickdfddlom, Cpfgijkhmbkphdib
   {
      
      public var screenWidth:int;
      
      public var screenOffsetY:int;
      
      public var screenOffsetX:int;
      
      public var screenHeight:int;
      
      public var screenAne:Cjblekeblbbkfgfk;
      
      public var scale:Number;
      
      public var safeAreaTopMargin:Number;
      
      public var safeAreaBottomMargin:Number;
      
      public var orientY:Number;
      
      public var orientX:Number;
      
      public var forceCutoutInsets:Option;
      
      public var canShowPlatformStatusBar:Boolean;
      
      public function Cogmdbohkpjobbkk(param1:Option = undefined)
      {
         var _gthis:Cogmdbohkpjobbkk;
         var forceCutoutInsets1:Option = param1;
         if(Boot.skip_constructor)
         {
            return;
         }
         _gthis = this;
         super();
         switch(forceCutoutInsets1.index)
         {
            case 0:
               forceCutoutInsets = Option.Some({
                  "left":0,
                  "top":0,
                  "right":0,
                  "bottom":0
               });
               Caeglnohendgolak.idmpnacbpkgbh(function():void
               {
                  _gthis.forceCutoutInsets = forceCutoutInsets1;
               },6);
               break;
            case 1:
               forceCutoutInsets = Option.None;
         }
         Ckmodbolbaonlijj.idkdembalebbg.stage.scaleMode = StageScaleMode.NO_SCALE;
         screenAne = new Cjblekeblbbkfgfk();
         screenAne.setLayoutInDisplayCutoutMode(1);
         resetScreenSize();
      }
      
      public function resetScreenSize() : void
      {
         var _loc1_:* = getScreenSize();
         screenWidth = int(_loc1_.screenWidth);
         screenHeight = int(_loc1_.screenHeight);
         screenOffsetX = int(_loc1_.screenOffsetX);
         screenOffsetY = int(_loc1_.screenOffsetY);
         orientX = Number(_loc1_.orientX);
         orientY = Number(_loc1_.orientY);
         scale = Number(_loc1_.scale);
         safeAreaTopMargin = Number(_loc1_.safeAreaTopMargin);
         safeAreaBottomMargin = Number(_loc1_.safeAreaBottomMargin);
         canShowPlatformStatusBar = Boolean(_loc1_.canShowPlatformStatusBar);
      }
      
      public function resetFullscreen() : void
      {
         screenAne.setLayoutInDisplayCutoutMode(1);
         Caeglnohendgolak.idmpnacbpkgbh(screenAne.resetFullscreen,6);
      }
      
      public function get_imageScale() : ImageScale
      {
         return ImageScale.Medium;
      }
      
      public function getScreenSize() : Object
      {
         return Canligbgjmcnadfb.idpokjdnmphpk(Option.Some(getScreenCutoutInsets()));
      }
      
      public function getScreenCutoutInsets() : Object
      {
         var _loc1_:Option = forceCutoutInsets;
         switch(_loc1_.index)
         {
            case 0:
               return _loc1_.params[0];
            case 1:
               return screenAne.getDisplayCutoutInsets();
            default:
               return;
         }
      }
   }
}

