// @target: obf.Capnigfjliohgnid
// @name: Desktop window: live resize, maximize, no debug overlay
// @desc: Makes the PC window behave like a normal desktop window. (1) When the
//        builder sees this patch enabled it turns resizable/maximizable on in
//        application-win.xml; this patch is what makes that safe, because a
//        native window size change only re-lays the game out if something
//        listens for it. (2) It clamps the window into the visible screen area
//        once at boot, so the packaged window cannot open with its footer bar
//        under the taskbar (clicks there land on the desktop). (3) It hides
//        the Haxe trace TextField that otherwise covers the whole game with
//        "ClassName.hx:123: ..." debug text. (4) It logs what it did to
//        wfbuilder-resize.log so a packaged build stays diagnosable.
// @enabled: true
// @platform: pc
// @config: keepOnScreen = true | Move the window fully inside the screen work area at boot (true/false)
// @config: hideDebugOverlay = true | Hide the on-screen trace text that covers the game (true/false)
//
// WHY THIS CLASS, AND NOT StarlingManager
// The obvious host is pinball.productionView.starling.StarlingManager: it owns
// the Starling stage and runs on the first boot step. But a whole-class replace
// of it - even a verbatim copy of FFDec's own decompiled source - kills the
// boot: DirectGear never finishes its preparation phase and the game floods
// `RealRemote/asyncUpdate TypeError #1009` (requestQueue never gets diffused).
// A plain class with no base class recompiles safely (that is why
// code-patches/server-redirect.as works), so this patch replaces such a class:
// obf.Capnigfjliohgnid is plain, is called from the boot script
// (boot_ffc6: Capnigfjliohgnid.idemjkfaofbjg()), already waits for the stage,
// and holds the global context as `idkcclmofpnjm:Top`.
//
// WHAT A RESIZE DOES
// This class only listens; the layout work is the game's own. On a native stage
// RESIZE it calls Top.view.notifyScreenSizeChanged(), i.e. exactly the code the
// game runs when the platform reports a new screen size. That refreshes the
// screen-size singleton (which re-reads stage.stageWidth/stageHeight, see
// patches-src/screen-fit-window.csx) and re-fits the Starling stage/viewport,
// so the world, the background, the fixed layers and pointer mapping all follow
// the new window size. The current screen keeps its build-time margins until it
// is rebuilt - deliberately: forcing a reload would park the client on the
// loading screen with this private server's incomplete CDN.
//
// WHOLE CLASS. Every member of the original obf.Capnigfjliohgnid is reproduced
// verbatim from the FFDec export; only the members under "LIVE RESIZE" are new,
// plus the single hookWindow() call at the end of idgogndbpahlf().

package obf
{
   import com.sesisoft.L8n;
   import flash.Boot;
   import flash.display.NativeWindow;
   import flash.display.Screen;
   import flash.display.Stage;
   import flash.events.Event;
   import flash.events.UncaughtErrorEvent;
   import flash.filesystem.File;
   import flash.filesystem.FileMode;
   import flash.filesystem.FileStream;
   import flash.geom.Rectangle;
   import haxe.ds.Option;
   import pinball.context.Top;
   import pinball.context.Trace;
   import pinball.context.reproduce.ReproduceLogEntry;
   import pinball.context.reproduce.SnapshotKind;

   public class Capnigfjliohgnid
   {

      public static var idkcclmofpnjm:Top;

      public function Capnigfjliohgnid()
      {
      }

      public static function idemjkfaofbjg() : void
      {
         Caeglnohendgolak.idmpnacbpkgbh(Capnigfjliohgnid.idgogndbpahlf,1);
      }

      public static function idgogndbpahlf() : void
      {
         var _loc1_:* = null;
         Trace.idfhjknkpbopf();
         Caekfmocfefkgija.idgfklahngegk().execute();
         if(Ckmodbolbaonlijj.idkdembalebbg.stage != null)
         {
            _loc1_ = null;
            Capnigfjliohgnid.idjimpkhekpgn([],Option.None,Option.None,_loc1_);
         }
         else
         {
            _loc1_ = null;
            Ckmodbolbaonlijj.idkdembalebbg.addEventListener(Event.ADDED_TO_STAGE,new Cbhhlmejgjlochob(Cohhhjkijbfmnhpm.idnloodllfgkk,new Coiiilhigdahkiao(Capnigfjliohgnid.idjimpkhekpgn,[],Option.None,Option.None,_loc1_).execute).execute);
         }
         Capnigfjliohgnid.hookWindow();
      }

      public static function idjimpkhekpgn(param1:Array, param2:Option, param3:Option, param4:Object) : void
      {
         var _loc6_:* = null as Cjocccdijojiedfm;
         L8n.idponaanfmngn();
         var _loc5_:Boolean = Capnigfjliohgnid.idkcclmofpnjm == null;
         switch(param3.index)
         {
            case 0:
               _loc6_ = param3.params[0];
               break;
            case 1:
               _loc6_ = Type.createInstance(Cjpkmijmnojjpeic.iddlmpcgmalba,[]);
         }
         if(Capnigfjliohgnid.idkcclmofpnjm != null)
         {
            Capnigfjliohgnid.idkcclmofpnjm.dispose();
         }
         if(int(param1.length) != 0)
         {
            _loc6_.snapshot.logicStatus.errorMessage = param1;
         }
         switch(param2.index)
         {
            case 0:
               _loc6_.reproduceLog = Option.Some(param2.params[0]);
               break;
            default:
            case 1:
         }
         switch(_loc6_.reproduceLog.index)
         {
            case 0:
               _loc6_.snapshot = new Cfmmjhfcmagihpki(SnapshotKind.Blank,new Clnboknobkbfomjh());
               break;
            default:
            case 1:
         }
         Capnigfjliohgnid.idkcclmofpnjm = new Top(Ckmodbolbaonlijj.idkdembalebbg,_loc6_,param4);
         Capnigfjliohgnid.idkcclmofpnjm.gearOutside().initializeTop(Option.None);
         if(_loc5_)
         {
            Ckmodbolbaonlijj.idkdembalebbg.loaderInfo.uncaughtErrorEvents.addEventListener(UncaughtErrorEvent.UNCAUGHT_ERROR,new Cbhhlmejgjlochob(Cebmdfncgplphacd.idgdkcnanodmd,Capnigfjliohgnid.idgfhkglbbdpb).execute);
            Cckdekiocjgmoned.idbfgdloplgam();
         }
      }

      public static function idgfhkglbbdpb(param1:Array) : void
      {
         var _loc2_:* = null;
         Caeglnohendgolak.idmpnacbpkgbh(new Coiiilhigdahkiao(Capnigfjliohgnid.idjimpkhekpgn,param1,Option.None,Option.None,_loc2_).execute,0);
      }

      // ================================================================
      // LIVE RESIZE - everything below is new (the code above is verbatim)
      // ================================================================

      public static var windowHooked:Boolean;

      public static var laidOutWidth:int;

      public static var laidOutHeight:int;

      public static var resizing:Boolean;

      public static var errorHookInstalled:Boolean;

      public static var logCount:int;

      // Runs once, at the end of the boot step that creates the Top context, so
      // the native stage exists and the window has just been placed. Hooks the
      // native stage RESIZE and, on request, moves the window into the visible
      // area. Deliberately does NOT re-lay-out at boot: nothing is on screen
      // yet and the game lays the first screen out from the size it reads now.
      public static function hookWindow() : void
      {
         var _loc1_:* = null;
         try
         {
            Capnigfjliohgnid.installErrorHook();
            if("{{hideDebugOverlay}}" == "true")
            {
               Capnigfjliohgnid.hideDebugOverlay();
            }
            _loc1_ = Ckmodbolbaonlijj.idkdembalebbg.stage;
            if(_loc1_ == null)
            {
               Capnigfjliohgnid.logLine("hook: no stage yet");
               return;
            }
            if(!Capnigfjliohgnid.windowHooked)
            {
               Capnigfjliohgnid.windowHooked = true;
               _loc1_.addEventListener("resize",Capnigfjliohgnid.onWindowResized,false,0,false);
               Capnigfjliohgnid.laidOutWidth = int(_loc1_.stageWidth);
               Capnigfjliohgnid.laidOutHeight = int(_loc1_.stageHeight);
               Capnigfjliohgnid.logLine("hook: listening, boot size " + Capnigfjliohgnid.laidOutWidth + "x" + Capnigfjliohgnid.laidOutHeight);
            }
            if("{{keepOnScreen}}" == "true")
            {
               Capnigfjliohgnid.clampWindowToScreen();
            }
         }
         catch(_loc2_:*)
         {
            Capnigfjliohgnid.logLine("hook: failed");
         }
      }

      // Haxe's trace() appends every line to Boot.lines and mirrors it into a
      // TextField (Boot.tf) that is added to the stage. On PC that field covers
      // the whole game with "pinball.scene.title.TitleScene.hx:214: ..." debug
      // text. getTrace() is the factory the runtime itself uses, so calling it
      // guarantees the field exists; hiding it then keeps every later trace off
      // screen (the text is still appended, it is simply not drawn).
      public static function hideDebugOverlay() : void
      {
         var _loc1_:* = null;
         try
         {
            _loc1_ = Boot.getTrace();
            if(_loc1_ == null)
            {
               _loc1_ = Boot.tf;
            }
            if(_loc1_ == null)
            {
               Capnigfjliohgnid.logLine("overlay: no trace field");
               return;
            }
            _loc1_.visible = false;
            _loc1_.mouseEnabled = false;
            _loc1_.selectable = false;
            Capnigfjliohgnid.logLine("overlay: hidden");
         }
         catch(_loc2_:*)
         {
            Capnigfjliohgnid.logLine("overlay: failed");
         }
      }

      // Moves (and, if it is larger than the screen, shrinks) the window so that
      // it is fully inside the work area - the screen minus the taskbar. AIR
      // centres a window using the full screen bounds, so the packaged 540x960
      // window can open with ~64px of its bottom under the taskbar; that is
      // where the footer bar is, and clicks there land on the desktop instead.
      public static function clampWindowToScreen() : void
      {
         var _loc1_:NativeWindow = null;
         var _loc2_:Rectangle = null;
         var _loc3_:Rectangle = null;
         try
         {
            _loc1_ = Ckmodbolbaonlijj.idkdembalebbg.stage.nativeWindow;
            if(_loc1_ == null)
            {
               return;
            }
            _loc2_ = Screen.mainScreen.visibleBounds;
            if(_loc2_ == null)
            {
               return;
            }
            _loc3_ = _loc1_.bounds.clone();
            if(_loc3_.width > _loc2_.width)
            {
               _loc3_.width = _loc2_.width;
            }
            if(_loc3_.height > _loc2_.height)
            {
               _loc3_.height = _loc2_.height;
            }
            if(_loc3_.x < _loc2_.x)
            {
               _loc3_.x = _loc2_.x;
            }
            if(_loc3_.y < _loc2_.y)
            {
               _loc3_.y = _loc2_.y;
            }
            if(_loc3_.right > _loc2_.right)
            {
               _loc3_.x = _loc2_.right - _loc3_.width;
            }
            if(_loc3_.bottom > _loc2_.bottom)
            {
               _loc3_.y = _loc2_.bottom - _loc3_.height;
            }
            if(!_loc3_.equals(_loc1_.bounds))
            {
               _loc1_.bounds = _loc3_;
               Capnigfjliohgnid.logLine("clamp: window -> " + _loc3_.x + "," + _loc3_.y + " " + _loc3_.width + "x" + _loc3_.height);
            }
            else
            {
               Capnigfjliohgnid.logLine("clamp: already inside " + _loc3_.x + "," + _loc3_.y + " " + _loc3_.width + "x" + _loc3_.height);
            }
         }
         catch(_loc4_:*)
         {
            Capnigfjliohgnid.logLine("clamp: failed");
         }
      }

      // A native window resize (including maximize / restore). Only re-runs the
      // layout when the render target really changed size; moving the window
      // fires the same event and must not trigger any of this. The window is
      // NOT clamped here: after boot the user may place it wherever they want.
      public static function onWindowResized(param1:Object) : void
      {
         if(Capnigfjliohgnid.resizing)
         {
            return;
         }
         Capnigfjliohgnid.resizing = true;
         try
         {
            var _loc2_:* = Ckmodbolbaonlijj.idkdembalebbg.stage;
            if(_loc2_ == null)
            {
               Capnigfjliohgnid.resizing = false;
               return;
            }
            var _loc3_:int = int(_loc2_.stageWidth);
            var _loc4_:int = int(_loc2_.stageHeight);
            Capnigfjliohgnid.logLine("resize: " + _loc3_ + "x" + _loc4_ + " (was " + Capnigfjliohgnid.laidOutWidth + "x" + Capnigfjliohgnid.laidOutHeight + ")");
            if(_loc3_ != Capnigfjliohgnid.laidOutWidth || _loc4_ != Capnigfjliohgnid.laidOutHeight)
            {
               Capnigfjliohgnid.laidOutWidth = _loc3_;
               Capnigfjliohgnid.laidOutHeight = _loc4_;
               Capnigfjliohgnid.relayoutForResize();
            }
         }
         catch(_loc5_:*)
         {
         }
         Capnigfjliohgnid.resizing = false;
      }

      // The game's own "the screen size changed" path, reached through the
      // global Top context. Top.view is the ProductionView; its
      // notifyScreenSizeChanged() refreshes the screen-size singleton and then
      // re-fits the Starling stage/viewport. Called dynamically so this class
      // does not have to depend on the view interface declaring that method.
      public static function relayoutForResize() : void
      {
         var _loc1_:* = Capnigfjliohgnid.idkcclmofpnjm;
         if(_loc1_ == null)
         {
            Capnigfjliohgnid.logLine("relayout: no Top yet");
            return;
         }
         try
         {
            if(_loc1_.screenSize != null)
            {
               _loc1_.screenSize.resetScreenSize();
            }
         }
         catch(_loc2_:*)
         {
         }
         try
         {
            _loc1_.view.notifyScreenSizeChanged();
            Capnigfjliohgnid.logLine("relayout: done");
            var _loc4_:* = _loc1_.screenSize;
            if(_loc4_ != null)
            {
               Capnigfjliohgnid.logLine("  screen=" + _loc4_.screenWidth + "x" + _loc4_.screenHeight + " offset=" + _loc4_.screenOffsetX + "," + _loc4_.screenOffsetY + " orient=" + _loc4_.orientX + "," + _loc4_.orientY + " scale=" + _loc4_.scale + " appViewPort=" + (1080 + _loc4_.orientX / _loc4_.scale * 2) + "x" + (1920 + _loc4_.orientY / _loc4_.scale * 2));
            }
         }
         catch(_loc3_:*)
         {
            Capnigfjliohgnid.logLine("relayout: failed");
         }
      }

      // A diagnostic trace, not part of the feature: appends to
      // %APPDATA%\com.kakaogames.wdfp\Local Store\wfbuilder-resize.log
      // (Documents as fallback), capped so an error loop cannot fill the disk.
      // Uncaught errors are logged too; this is how a boot failure caused by a
      // code patch can be read out of a packaged, released-runtime build.
      public static function installErrorHook() : void
      {
         try
         {
            if(Capnigfjliohgnid.errorHookInstalled)
            {
               return;
            }
            Capnigfjliohgnid.errorHookInstalled = true;
            Ckmodbolbaonlijj.idkdembalebbg.loaderInfo.uncaughtErrorEvents.addEventListener(UncaughtErrorEvent.UNCAUGHT_ERROR,Capnigfjliohgnid.onUncaughtError,false,0,false);
         }
         catch(_loc1_:*)
         {
         }
      }

      public static function onUncaughtError(param1:Object) : void
      {
         var _loc2_:* = null;
         try
         {
            _loc2_ = param1.error;
            Capnigfjliohgnid.logLine("UNCAUGHT " + (_loc2_ == null ? "?" : String(_loc2_)));
            if(_loc2_ != null && _loc2_.getStackTrace != null)
            {
               Capnigfjliohgnid.logLine("  stack: " + _loc2_.getStackTrace());
            }
         }
         catch(_loc3_:*)
         {
         }
      }

      public static function logLine(param1:String) : void
      {
         var _loc2_:File = null;
         var _loc3_:FileStream = null;
         try
         {
            if(Capnigfjliohgnid.logCount >= 400)
            {
               return;
            }
            Capnigfjliohgnid.logCount++;
            try
            {
               _loc2_ = File.applicationStorageDirectory.resolvePath("wfbuilder-resize.log");
            }
            catch(_loc4_:*)
            {
               _loc2_ = File.documentsDirectory.resolvePath("wfbuilder-resize.log");
            }
            _loc3_ = new FileStream();
            _loc3_.open(_loc2_,FileMode.APPEND);
            _loc3_.writeUTFBytes(param1 + "\n");
            _loc3_.close();
         }
         catch(_loc5_:*)
         {
         }
      }
   }
}
