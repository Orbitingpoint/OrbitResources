package pinball.context.reproduce
{
   import flash.Boot;
   import flash.filesystem.File;
   import jp.sipo.gipo.reproduce.Reproduce;
   import obf.Cacmpaoippcnnjad;
   import obf.Cdhmjhdbacbooele;
   import obf.Cebmdfncgplphacd;
   import obf.Cjocccdijojiedfm;
   import obf.Cliaecpmnflacjfp;
   import obf.Cpdnglnlhlggklga;
   
   public class AdvancedReproduce extends Reproduce
   {
      
      public static var __meta__:* = {"fields":{"devConfig":{"absorb":["obf.Cjocccdijojiedfm"]}}};
      
      public var replayEndHandlers:Array;
      
      public var record:Boolean;
      
      public var rawRecorder:ReproduceFileRecordImpl;
      
      public var devConfig:Cjocccdijojiedfm;
      
      public function AdvancedReproduce(param1:Boolean = false)
      {
         if(Boot.skip_constructor)
         {
            return;
         }
         super();
         record = param1;
         replayEndHandlers = [];
         gear.addPreparationHandler(advancedPreparation,{
            "fileName":"pinball/context/reproduce/AdvancedReproduce.hx",
            "lineNumber":36,
            "className":"pinball.context.reproduce.AdvancedReproduce",
            "methodName":"new"
         });
         gear.addRunHandler(advancedRun,{
            "fileName":"pinball/context/reproduce/AdvancedReproduce.hx",
            "lineNumber":37,
            "className":"pinball.context.reproduce.AdvancedReproduce",
            "methodName":"new"
         });
      }
      
      override public function startRecord() : void
      {
         var _loc1_:* = null as File;
         var _loc2_:* = null as ReproduceFileRecordImpl;
         if(recorder != null)
         {
            gear.removeChild(recorder);
         }
         if(record)
         {
            _loc1_ = devConfig.getStorageDirectory().resolvePath("latest.log");
            recorder = rawRecorder = gear.addChild(new ReproduceFileRecordImpl(_loc1_),{
               "fileName":"pinball/context/reproduce/AdvancedReproduce.hx",
               "lineNumber":79,
               "className":"pinball.context.reproduce.AdvancedReproduce",
               "methodName":"startRecord"
            });
         }
         else
         {
            recorder = gear.addChild(new Cdhmjhdbacbooele(),{
               "fileName":"pinball/context/reproduce/AdvancedReproduce.hx",
               "lineNumber":84,
               "className":"pinball.context.reproduce.AdvancedReproduce",
               "methodName":"startRecord"
            });
         }
      }
      
      override public function replayEnd(param1:Boolean) : void
      {
         var _loc4_:* = null as Function;
         super.replayEnd(param1);
         var _loc2_:int = 0;
         var _loc3_:Array = replayEndHandlers;
         while(_loc2_ < int(_loc3_.length))
         {
            _loc4_ = _loc3_[_loc2_];
            _loc2_++;
            _loc4_();
         }
         removeReplayEndHandlerAll();
      }
      
      public function removeReplayEndHandlerAll() : void
      {
         replayEndHandlers.length = 0;
      }
      
      public function getDataString() : String
      {
         if(!record)
         {
            throw new Cpdnglnlhlggklga(1010,"idzzzlzzzzzzzzzzzz");
         }
         return rawRecorder.getDataString();
      }
      
      public function close() : void
      {
         if(rawRecorder != null)
         {
            rawRecorder.close();
         }
      }
      
      public function advancedRun() : void
      {
      }
      
      public function advancedPreparation(param1:Cliaecpmnflacjfp) : void
      {
         try
         {
            Cebmdfncgplphacd.idbhhndcoocjj();
         }
         catch(e:Error)
         {
         }
      }
      
      public function addReplayEndHandler(param1:Function) : void
      {
         replayEndHandlers.push(param1);
      }
   }
}

