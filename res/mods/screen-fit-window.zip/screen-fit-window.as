package obf
{
   import haxe.ds.Option;
   
   public class Canligbgjmcnadfb
   {
      
      public function Canligbgjmcnadfb()
      {
      }
      
      public static function idfjinkohchbc() : Object
   {
      var _loc1_:uint = Ckmodbolbaonlijj.idkdembalebbg.stage.stageWidth;
      var _loc2_:uint = Ckmodbolbaonlijj.idkdembalebbg.stage.stageHeight;
      return {
         "screenWidth":int(_loc1_),
         "screenHeight":int(_loc2_)
      };
   }
   
   public static function idpokjdnmphpk(param1:Option) : Object
      {
         var _loc7_:Number = NaN;
         var _loc8_:Number = NaN;
         var _loc12_:* = null;
         var _loc13_:Number = NaN;
         var _loc14_:Number = NaN;
         var _loc15_:Number = NaN;
         var _loc16_:Number = NaN;
         var _loc18_:Number = NaN;
         var _loc2_:* = Canligbgjmcnadfb.idfjinkohchbc();
         var _loc3_:int = int(_loc2_.screenHeight);
         var _loc4_:int = int(_loc2_.screenWidth);
         var _loc5_:int = 0;
         var _loc6_:Number = _loc4_ / _loc3_;
         if(_loc6_ < 0.5625)
         {
            _loc8_ = _loc4_ / 0.5625;
            _loc7_ = _loc8_ / 1920;
         }
         else
         {
            _loc7_ = _loc3_ / 1920;
         }
         _loc8_ = 0;
         var _loc9_:Number = 0;
         if(_loc6_ < 0.49)
         {
            _loc8_ = 115;
            _loc9_ = 89;
         }
         var _loc10_:int = 0;
         var _loc11_:int = 0;
         switch(param1.index)
         {
            case 0:
               _loc12_ = param1.params[0];
               _loc13_ = 0;
               _loc14_ = 0;
               if(Number(_loc12_.top) > _loc8_ * _loc7_)
               {
                  _loc13_ = Number(_loc12_.top) - _loc8_ * _loc7_;
               }
               if(Number(_loc12_.bottom) > _loc9_ * _loc7_)
               {
                  _loc14_ = Number(_loc12_.bottom) - _loc9_ * _loc7_;
               }
               _loc15_ = _loc4_ / (_loc3_ - (_loc8_ + _loc9_) * _loc7_ - (_loc13_ + _loc14_));
               if(_loc15_ > 0.5625)
               {
                  _loc10_ = int(Math.floor(_loc13_ + 1e-10 + 1e-10 + 1e-10 + 1e-10));
                  _loc11_ = int(Math.floor(_loc14_ + 1e-10 + 1e-10 + 1e-10 + 1e-10));
                  _loc3_ -= _loc10_ + _loc11_;
                  _loc5_ = _loc10_;
               }
               else
               {
                  _loc8_ += _loc13_ / _loc7_;
                  _loc9_ += _loc14_ / _loc7_;
               }
               break;
            default:
            case 1:
         }
         _loc6_ = _loc4_ / _loc3_;
         if(_loc6_ < 0.5625)
         {
            _loc16_ = _loc4_ / 0.5625;
            _loc13_ = 0;
            _loc14_ = (_loc3_ - _loc16_) / 2;
            _loc15_ = _loc16_ / 1920;
         }
         else
         {
            _loc13_ = (_loc4_ - _loc3_ * 0.5625) / 2;
            _loc14_ = 0;
            _loc15_ = _loc3_ / 1920;
         }
         var _loc17_:Boolean = _loc4_ <= 755 && _loc4_ >= 745 && _loc3_ <= 1339 && _loc3_ >= 1329;
         if(_loc17_)
         {
            _loc13_ += (_loc4_ - (719.928 + _loc13_ * 2)) / 2;
            _loc14_ += (_loc3_ - (1279.8719999999998 + _loc14_ * 2)) / 2;
            _loc15_ = 0.6666;
         }
         _loc16_ = _loc3_ / _loc15_;
         if(_loc16_ > 2339)
         {
            _loc18_ = (_loc16_ - 2339) * _loc15_;
            _loc3_ -= int(Math.floor(_loc18_ + 1e-10 + 1e-10));
            _loc5_ += int(Math.floor(_loc18_ / 2 + 1e-10 + 1e-10));
            _loc13_ = 0;
            _loc14_ = (_loc3_ - _loc4_ / 0.5625) / 2;
         }
         var _loc19_:Boolean = _loc6_ < 0.49;
         return {
            "orientX":_loc13_,
            "orientY":_loc14_,
            "screenWidth":_loc4_,
            "screenHeight":_loc3_,
            "screenOffsetX":0,
            "screenOffsetY":_loc5_,
            "scale":_loc15_,
            "safeAreaTopMargin":_loc8_,
            "safeAreaBottomMargin":_loc9_,
            "canShowPlatformStatusBar":_loc19_
         };
      }
   }
}

